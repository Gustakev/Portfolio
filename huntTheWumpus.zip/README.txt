This program runs on Windows 10 and above.

This program offers a classic implementation of the "Hunt the Wumpus" game.

Open command prompt. Then, enter this folder. Then, run this program by typing this: huntTheWumpus.exe