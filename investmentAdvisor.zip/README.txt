This program runs on Windows 10 and above.

Open command prompt. Then, enter this folder. Then, run this program by typing this: investmentAdvisor.exe