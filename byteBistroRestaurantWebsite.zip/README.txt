This website can run on a local server, as of now.

Firstly, you must enter the "websiteFiles" directory using a terminal program, such as Git Bash.

Then, you must enter "npm i" to install the necessary packages.

Then, you must launch "server.js" using node.js by entering "node server.js".

Now, the website should by live and accessible at "http://localhost:3000".