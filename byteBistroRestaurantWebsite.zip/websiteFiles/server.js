const exphbs = require('express-handlebars');
const path = require('path');

const express = require('express');

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.engine('handlebars', exphbs.engine({
    defaultLayout: 'main',
    layoutsDir: path.join(__dirname, 'views', 'layouts'),
    helpers: {
        eq: (a, b) => a === b
    }
}));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// Middleware setup
app.use(express.json());

// Adding GET /reviews route
const fs = require('fs');
const reviewsFile = path.join(__dirname, 'data', 'reviews.json');

app.get('/reviews', (req, res) => {
    fs.readFile(reviewsFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading reviews.json:', err);
            return res.status(500).json({ error: 'Could not load reviews.' });
        }

        let reviews = [];
        try {
            reviews = JSON.parse(data);
        } catch {
            console.error('Invalid JSON format');
        }

        res.json(reviews);
    });
});

// Adding POST /submit-review route
app.post('/submit-review', (req, res) => {
    const newReview = req.body;

    fs.readFile(reviewsFile, 'utf8', (err, data) => {
        let reviews = [];

        if (!err && data) {
            try {
                reviews = JSON.parse(data);
            } catch (parseErr) {
                console.error('Error parsing existing reviews:', parseErr);
            }
        }

        reviews.push(newReview);

        fs.writeFile(reviewsFile, JSON.stringify(reviews, null, 2), (writeErr) => {
            if (writeErr) {
                console.error('Error writing to reviews.json:', writeErr);
                return res.status(500).json({ error: 'Failed to save review.' });
            }

            res.status(200).json({ message: 'Review saved successfully!' });
        });
    });
});

const ordersFile = path.join(__dirname, 'data/orders.json');

app.get('/manager-dashboard', (req, res) => {
    const cityFilter = req.query.city;
    const deliveriesOnly = req.query.deliveriesOnly === 'on'; // Set if the checkbox is clicked.

    fs.readFile(ordersFile, 'utf8', (err, data) => {
        if (err) return res.status(500).send('Error loading orders.');

        let orders = JSON.parse(data);

        if (cityFilter && cityFilter !== "All") {
            orders = orders.filter(order => order.city === cityFilter);
        }
        
        // Narrowing results to only delivery orders.
        if (deliveriesOnly) {
            orders = orders.filter(order => order.delivery === true);
        }

        const orderCount = orders.length;
        let totalRevenue = 0;

        // Accumulate the summary stats.
        orders.forEach(order => {
            totalRevenue += order.total || 0;
        });

        let deliveryCount = 0;
        let noCitySelected = false;

        // Determining if a city was selected.
        if (!(cityFilter && cityFilter !== "All")) {
            noCitySelected = true;
        }

        // Accumulate the number of deliveries.
        orders.forEach(order => {
            if (order.delivery === true) {
                deliveryCount += 1;
            }
        });

        // Getting the average total.
        let averageTotal = orderCount > 0 ? (totalRevenue / orderCount).toFixed(2) : "0.00";

        res.render('manager-dashboard', {
            title: 'Manager Dashboard',
            activePage: 'dashboard',
            extraStyles: '',
            orders,
            cityFilter,
            orderCount,
            totalRevenue: totalRevenue.toFixed(2),
            deliveryCount,
            averageTotal,
            noCitySelected,
            deliveriesOnly
        });
    });
});

app.listen(PORT, () => {
    console.log(`Byte Bistro server running at http://localhost:${PORT}`);
});