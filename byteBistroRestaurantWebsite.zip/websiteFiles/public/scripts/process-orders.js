/*
  Name: Kevin Gustafson
  Date: 4/28/2025
  Class: CS 290 – Web Development

  Instructions:
  - Add your name, date, and class above.
  - Provide a detailed comment header before each function describing what it does.
  - Leave all TODO comments in place while working. Remove them only after completing each function.
  - Use clear variable names and add inline comments to explain your logic.
*/

const orders = require('./orders.js');
const deliveryFee = 3.00;

// Byte Bistro Menu – price map
const priceMap = {
  "Veggie Mac": 8.00,
  "Tofu Tacos": 9.50,
  "Byte Burger": 11.25,
  "Curry Bowl": 12.00,
  "Recursive Ravioli": 13.50,
  "Iced Tea": 2.50,
  "Soda": 2.00,
  "Coffee": 2.00,
  "Byte Brownie": 4.00,
  "Lava Cake": 5.00,
  "Vanilla Cheesecake": 4.50,
  "extra salsa": 0.50,
  "extra cheese": 1.00,
  "side of rice": 2.00
};

/**
 * Name: findOrderByCustomer
 * Purpose: Finds the first order where the customer matches the name.
 * @param {Array} orders
 * @param {String} name
 * @return {Object | null}
 */
function findOrderByCustomer(orders, name) {
  return orders.find(function(order) {
    return order.customer === name; // Returns the object of the specified customer's order.
  }) || null; // Returns null if the customer was not found.
}

/**
 * Name: calculateSubtotal
 * Purpose: Calculates the subtotal.
 * @param {Object} order
 * @param {Object} prices
 * @return {Subtotal}
 */
function calculateSubtotal(order, prices) {
  // Variable for subtotal.
  let subtotal = 0;

  // Adding up the entree costs.
  if (Array.isArray(order.entrees)) {
    order.entrees.forEach(function(item) {
      subtotal += prices[item.name] * item.quantity;
    });
  }

  // Adding up the drink costs.
  if (Array.isArray(order.drinks)) {
    order.drinks.forEach(function(item) {
      subtotal += prices[item.name] * item.quantity;
    });
  }

  // Adding up the dessert costs.
  if (Array.isArray(order.desserts)) {
    order.desserts.forEach(function(item) {
      subtotal += prices[item.name] * item.quantity;
    });
  }

  // Adding up the addOn costs (no multiplier).
  if (Array.isArray(order.addOns)) {
    order.addOns.forEach(function(addOn) {
      subtotal += prices[addOn];
    });
  }

  // Returning the subtotal.
  return subtotal;
}

/**
 * Name: calculateTip
 * Purpose: Calculates the tip amount and returns it.
 * @param {Number} subtotal 
 * @param {Number} percent 
 * @return {Tip Amount}
 */
function calculateTip(subtotal, percent) {
  // Doing the math.
  return subtotal * percent / 100;
}

/**
 * Name: printReceipt
 * Purpose: Prints the receipt for the customer.
 * @param {Object} order 
 * @param {Object} prices 
 */
function printReceipt(order, prices) {
  // TODO: Print receipt header and entrée items
  console.log("EPIC BYTE BISTRO RECEIPT – " + order.customer);
  console.log("Date: " + order.date);
  console.log("----------------------------------------");

  // Printing out the cost of all entrees.
  if (Array.isArray(order.entrees)) {
    order.entrees.forEach(function(item) {
      const cost = prices[item.name] * item.quantity;
      console.log("Entrée: " + item.name + " x" + item.quantity + " – $" + cost.toFixed(2));
    });
  }

  // Printing out the cost of all drinks.
  if (Array.isArray(order.drinks)) {
    order.drinks.forEach(function(item) {
      const cost = prices[item.name] * item.quantity;
      console.log("Drink: " + item.name + " x" + item.quantity + " – $" + cost.toFixed(2));
    });
  }

  // Printing out the cost of all desserts.
  if (Array.isArray(order.desserts)) {
    order.desserts.forEach(function(item) {
      const cost = prices[item.name] * item.quantity;
      console.log("Dessert: " + item.name + " x" + item.quantity + " – $" + cost.toFixed(2));
    });
  }

  // Printing out the cost of all addOns.
  if (Array.isArray(order.addOns)) {
    order.addOns.forEach(function(addOn) {
      const cost = prices[addOn];
      console.log("Add-on: " + addOn + " – $" + cost.toFixed(2));
    });
  }

  // Calculating the subtotal and tip.
  const subtotal = calculateSubtotal(order, prices);
  const tip = calculateTip(subtotal, order.tipPercent);
  
  // Calculating the total with or without the delivery fee.
  let total;
  if (order.delivery) {
    total = subtotal + tip + deliveryFee;
  } else {
    total = subtotal + tip;
  }

  // Printing out the delivery fee, the subtotal, the tip amount, and the total.
  console.log("----------------------------------------");
  // Printing the delivery fee if it applies.
  if (order.delivery) {
    console.log("Delivery Fee: " + deliveryFee.toFixed(2));
  }
  console.log("Subtotal: $" + subtotal.toFixed(2));
  console.log("Tip (" + order.tipPercent + "%): " + tip.toFixed(2));
  console.log("TOTAL: $" + total.toFixed(2) + "\n");
}

/**
 * Name: summarizeOrdersByDate
 * Purpose: Summarizes the orders, grouping them by date and tracking total and count.
 * @param {Object} orders 
 */
function summarizeOrdersByDate(orders) {
  // Object to represent the summary, by date.
  const summary = {};

  // Initializing the summary entry for a date.
  orders.forEach(function(order) {
    if (!summary[order.date]) {
      summary[order.date] = { total: 0, count: 0 };
    }

    // Calculating amounts.
    const subtotal = calculateSubtotal(order, priceMap);
    let delivery = 0.00;
    if (order.delivery) {
      delivery = 3.00;
    }
    const tip = calculateTip(subtotal, order.tipPercent);

    // Calculating the overall total.
    summary[order.date].total += subtotal + delivery + tip;

    // Incrementing the order count.
    summary[order.date].count += 1;
  });

  console.log("----------------------------------------");
  console.log("Daily Sales Summary:");
  for (const date in summary) {
    const day = summary[date];
    const average = day.total / day.count;
    console.log(`Date: ${date} | Orders: ${day.count} | Revenue: $${day.total.toFixed(2)} | Avg: $${average.toFixed(2)}`);
  }
}

/**
 * Name: validateOrder
 * Purpose: Validates an order or denies it.
 * @param {Object} order 
 * @returns {Boolean}
 */
function validateOrder(order) {
  // Checking for the customer name and date.
  if (!order.customer || !order.date) {
    console.log("**** ERROR ADDING ORDER: Name or date invalid or nonexistent. ****");
    return false;
  }

  // Ensuring there is at least one entrée, drink, or dessert in the order.
  let isEntree = (Array.isArray(order.entrees) && order.entrees.length > 0);
  let isDrink = (Array.isArray(order.drinks) && order.drinks.length > 0);
  let isDessert = (Array.isArray(order.desserts) && order.desserts.length > 0);

  // Printing the error statement and returning false if none of them are true.
  if (!(isEntree || isDrink || isDessert)) {
    console.log("**** ERROR ADDING ORDER: Must purchase at least a single entrée, drink, or dessert. ****");
    return false;
  }

  // Else
  return true;
}

/**
 * Name: addOrder
 * Purpose: Adds an order upon successful validation.
 * @param {Array} orders 
 * @param {Object} newOrder 
 */
function addOrder(orders, newOrder) {
  // Checks if the order is valid. If so, adds it and prints out adding statement.
  if (validateOrder(newOrder)) {
    orders.push(newOrder);
    console.log(`**** ORDER ADDED FOR ${newOrder.customer} on ${newOrder.date} ****\n`);
  } else {
    console.log(`**** ORDER NOT ADDED ****\n`);
  }
}

// --- TESTING SECTION (Call Your Functions Below) ---

// Find a customer's order and print it
const order = findOrderByCustomer(orders, "Willy");
if (order) printReceipt(order, priceMap);

// Add a new good order
const newOrder = {
  customer: "Test Customer",
  date: "2025-04-23",
  delivery: true,
  tipPercent: 12,
  entrees: [{ name: "Byte Burger", quantity: 1 }],
  drinks: [{ name: "Coffee", quantity: 1 }],
  desserts: [{ name: "Byte Brownie", quantity: 1 }],
  addOns: ["extra cheese"]
};
addOrder(orders, newOrder);

// Invalid order (should fail validation)
const badOrder = {
  customer: "Bad Customer 1",
  date: "2025-04-24",
  delivery: false,
  tipPercent: 15,
  entrees: [],
  drinks: [],
  desserts: [],
  addOns: []
};
addOrder(orders, badOrder);

// Other invalid order (should fail validation)
const badOrderTwo = {
  customer: "Bad Customer 2",
  date: "",
  delivery: false,
  tipPercent: 15,
  entrees: [{ name: "Byte Burger", quantity: 1 }],
  drinks: [],
  desserts: [],
  addOns: []
};
addOrder(orders, badOrderTwo);

// Other invalid order (should fail validation)
const badOrderThree = {
  customer: "",
  date: "2025-04-24",
  delivery: false,
  tipPercent: 15,
  entrees: [{ name: "Byte Burger", quantity: 1 }],
  drinks: [],
  desserts: [],
  addOns: []
};
addOrder(orders, badOrderThree);

// Print all receipts and daily summary
orders.forEach(function(order) {
  printReceipt(order, priceMap);
});
summarizeOrdersByDate(orders);
