// Arrays to store each type of item.
let entrees = [];
let desserts = [];
let beverages = [];

// Setting the delivery fee.
const deliveryFee = 3.00;

// Setting the prices for each item.
const priceMap = {
    "Red 40 Burger": 15.00,
    "Red 40 Taco": 4.50,
    "Red 40 Nacho Fries": 6.00,
    "Red 40 Sub": 12.00,
    "Red 40 Smoothie": 4.00,
    "Red 40 Protein Shake": 4.00,
    "Red 40 Slopper": 6.00,
    "Red 40 Cake": 25.00,
    "Red 40 Pie": 20.00,
    "Taki Dust": 0.20,
    "Chamoy Pickles": 0.20,
    "Red 40 Seasoning": 0.20
};

// Attach event listeners to each .menu-item
document.querySelectorAll('.menu-item').forEach((item) => {
    item.addEventListener('click', handleItemClick);
    item.querySelector('.qty-input').addEventListener('input', updateSelectedItems);
});

/**
 * Name: handleItemClick
 * Purpose: Handles click on a menu item
 * @param {event} event
 */
function handleItemClick(event) {
    // Storing the attributes of the clicked item in constants.
    const item = event.currentTarget;
    const name = item.dataset.name;
    const price = parseFloat(item.dataset.price); // Converting the string to a number.
    const category = item.dataset.category;

    // Ceasing execution of this function if a button, either confirm or cancel, was selected.
    if (event.target.classList.contains('update-btn') || event.target.classList.contains('cancel-btn')) {
        return;
    }

    // Logging the details of the item to the console.
    console.log(`Clicked: ${name} | Price: $${price.toFixed(2)} | Category: ${category}`)

    // Change the visibility of the quantity input for the clicked item.
    const qtyInput = item.querySelector('.qty-input');
    if (qtyInput.style.display === 'none') { // Displaying input box.
        qtyInput.style.display = 'block';
        qtyInput.focus(); // Focusing the user's keyboard inputs to the box.
    } else {
        qtyInput.style.display = 'none'; // Removing input box from view.
        qtyInput.value = '';
        removeSelectedItems(item); // Clearing the item from the selection list.
    }
}

/**
 * Name: updateSelectedItems
 * Purpose: Handles quantity input changes
 * @param {event} event
 */
function updateSelectedItems(event) {
    event.stopPropagation(); // Preventing bubbling up, ensuring the input is visible.

    const qtyInput = event.target; // the number input box that was changed

    // Use closest() to safely find the menu-item container even if structure changes
    const item = qtyInput.closest('.menu-item');
    const name = item.dataset.name; // The name.

    // Ensures that if there is no data qty is set to 0 via short circuit.
    const qty = parseInt(qtyInput.value) || 0; // The quantity of the item.

    const category = item.dataset.category // Adding a category variable.

    // Debugging.
    console.log("Updated input field value: ", qtyInput.value);

    // Log the updated quantity for that specific item
    console.log(`Updated quantity: ${name} × ${qty}`);

    // Add functionality for updating and cancelling items
    const updateButton = item.querySelector('.update-btn');
    const cancelButton = item.querySelector('.cancel-btn');

    // If the quantity is greater than 0, show the buttons. Else, don't.
    if (qty > 0) {
        updateButton.style.display = 'inline-block';
        cancelButton.style.display = 'inline-block';

        // Removes existing entries and re-adds them with the new quantity.
        if (category === 'entree') {
            entrees = entrees.filter(i => i.name !== name); // Filters through the array,
                                                            //  filtering out the items that match this name.
            entrees.push({ name, qty }); // Adding the item back but with the correct quantity.
        } else if (category === 'dessert') {
            desserts = desserts.filter(i => i.name !== name);
            desserts.push({ name, qty });
        } else if (category === 'beverage') {
            beverages = beverages.filter(i => i.name !== name);
            beverages.push({ name, qty });
        }
    } else { // Removing the item if the item is 0 or less and hiding the buttons.
        updateButton.style.display = 'none';
        cancelButton.style.display = 'none';
        
        // Removing the item.
        removeSelectedItems(item);
    }

    // Function that udpates the sidebar's data for alignment.
    updateSidebar();
}

/**
 * Name: removeSelectedItems
 * Purpose: Removes items from order list and sidebar.
 * @param {object} item
 */
function removeSelectedItems(item) {
    const category = item.dataset.category; // Category var.
    const name = item.dataset.name; // Constant for the name of the item.

    // Logic to remove the item entirely, without readding anything.
    if (category === 'entree') {
        entrees = entrees.filter(i => i.name !== name);
    } else if (category === 'dessert') {
        desserts = desserts.filter(i => i.name !== name);
    } else if (category === 'beverage') {
        beverages = beverages.filter(i => i.name !== name);
    }

    updateSidebar(); // Refresh the sidebar so it aligns with the new info.
    console.log(`Unselected: ${name}`); // Logging the name of the item removed.
}

/**
 * Name: handleConfirmClick
 * Purpose: Handles the clicking of the confirm button.
 * @param {event} event
 */
function handleConfirmClick(event) {
    // Constants for the item and its quantity.
    const menuItem = event.currentTarget.closest('.menu-item');
    const qtyInput = menuItem.querySelector('.qty-input');

    // Constants for the buttons.
    const updateButton = menuItem.querySelector('.update-btn');
    const cancelButton = menuItem.querySelector('.cancel-btn');

    // Logging a confirmation.
    console.log(`Selection Updated: ${menuItem.dataset.name} × ${qtyInput.value}`);

    qtyInput.style.display = 'none'; // Hiding the input field once it has been logged.

    // Hiding the buttons once once has been clicked.
    updateButton.style.display = 'none';
    cancelButton.style.display = "none";

    // REMOVED FOR NOW
    /*
    // Showing a message that the order has been updated.
    if (parseInt(qtyInput.value) > 0) {
        // Assigning a variable the current update message, if it exists.
        let existingMessage = menuItem.querySelector('.update-message');

        // If it does exist, remove it.
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create a new success message.
        let newElement = document.createElement("p");
        newElement.classList.add("update-message"); // Assign the identifiable class to the element.
        newElement.textContent = `Order updated!: ${qtyInput.value} Item(s).`;

        // Inserting a success message below the description of the item.
        let descriptionElement = menuItem.querySelector('.description'); 
        descriptionElement.insertAdjacentElement("afterend", newElement);
    }
    */

    updateSidebar(); // Refreshing the sidebar when confirmed.
}

/**
 * Name: handleCancelClick
 * Purpose: Handles the clicking of the cancel button.
 * @param {event} event
 */
function handleCancelClick(event) {
    event.stopPropagation(); // Preventing bubbling up, ensuring the input is visible.

    // Constants for the item and its quantity.
    const menuItem = event.currentTarget.closest('.menu-item');
    const qtyInput = menuItem.querySelector('.qty-input');

    // Constants for the buttons.
    const updateButton = menuItem.querySelector('.update-btn');
    const cancelButton = menuItem.querySelector('.cancel-btn');

    // Name and category variables to manipulate.
    const name = menuItem.dataset.name;
    const category = menuItem.dataset.category;

    // Logging a cancelation.
    console.log(`Selection Canceled: ${menuItem.dataset.name}`);

    qtyInput.value = ''; // Clearing the input for quantity once the info has been logged.
    qtyInput.style.display = 'none'; // Hiding the input field once it has been logged.

    // Hiding the buttons once once has been clicked.
    updateButton.style.display = 'none';
    cancelButton.style.display = "none";

    // Logic to remove the item entirely, without readding anything.
    if (category === 'entree') {
        entrees = entrees.filter(i => i.name !== name);
    } else if (category === 'dessert') {
        desserts = desserts.filter(i => i.name !== name);
    } else if (category === 'beverage') {
        beverages = beverages.filter(i => i.name !== name);
    }

    updateSidebar(); // Ensuring the sidebar is updated upon cancelation.
}

// Adding event listeners to the confirm buttons.
document.querySelectorAll('.update-btn').forEach(button => {
    button.addEventListener('click', handleConfirmClick);
});

// Adding event listeners to the cancel buttons.
document.querySelectorAll('.cancel-btn').forEach(button => {
    button.addEventListener('click', handleCancelClick);
});

/**
 * Name: updateSidebar
 * Purpose: Updating the sidebar when something changes.
 */
function updateSidebar() {
    // Sets the HTML of the document to the following string.
    document.getElementById('entree-list').innerHTML =
        entrees.map(item => `<li>${item.name} × ${item.qty}</li>`).join(''); // If it is an entree, set the sidebar content.
    document.getElementById('dessert-list').innerHTML =
        desserts.map(item => `<li>${item.name} × ${item.qty}</li>`).join(''); // etc.
    document.getElementById('beverage-list').innerHTML =
        beverages.map(item => `<li>${item.name} × ${item.qty}</li>`).join(''); // etc.
}

//***********************
// Activity 11 Additions
//***********************

/**
 * Name: buildOrderObject
 * Purpose: Function that returns an order object.
 */
function buildOrderObject() {
    return {
        customer: document.getElementById("name").value,
        date: getTodayDateString(),
        delivery: document.getElementById("delivery").checked, // Gets whether the order is a delivery right here.
        tipPercent: parseFloat(document.querySelector('input[name="tip"]:checked')?.value || 0),
        entrees: entrees,
        drinks: beverages,
        desserts: desserts,
        addOns: getSelectedAddOns()
    };
}

/**
 * Name: getTodayDateString
 * Purpose: Getting the date as a string.
 */
function getTodayDateString() {
    const today = new Date(); // Returns the new date object.
    return today.toISOString().split('T')[0]; // Returns the date as a string in year, month, day format.
}

/**
 * Name: getSelectedAddOns
 * Purpose: Getting the selected addons.
 */
function getSelectedAddOns() {
    const checkboxes = document.querySelectorAll('input[name="addons[]"]:checked'); // Selects all the checkboxes that are checked.
    const checkboxArray = Array.from(checkboxes); // Array from the checkboxes.
    return checkboxArray.map(function(chkbx) { // Loops through each value in each checkbox.
        return chkbx.value; // Returns the value.
    })
}

/**
 * Name: calculateSubtotal
 * Purpose: Calculates the subtotal.
 * @param {Object} order
 * @param {Object} prices
 * @return {Subtotal}
 */
function calculateSubtotal(order, prices) {
    // Variable for subtotal.
    let subtotal = 0;
  
    // Adding up the entree costs.
    if (Array.isArray(order.entrees)) {
      order.entrees.forEach(function(item) {
        subtotal += prices[item.name] * item.qty;
      });
    }
  
    // Adding up the drink costs.
    if (Array.isArray(order.drinks)) {
      order.drinks.forEach(function(item) {
        subtotal += prices[item.name] * item.qty;
      });
    }
  
    // Adding up the dessert costs.
    if (Array.isArray(order.desserts)) {
      order.desserts.forEach(function(item) {
        subtotal += prices[item.name] * item.qty;
      });
    }
  
    // Adding up the addOn costs (no multiplier).
    if (Array.isArray(order.addOns)) {
      order.addOns.forEach(function(addOn) {
        subtotal += prices[addOn];
      });
    }
  
    // Returning the subtotal.
    return subtotal;
  }
  
/**
 * Name: calculateTip
 * Purpose: Calculates the tip amount and returns it.
 * @param {Number} subtotal 
 * @param {Number} percent 
 * @return {Tip Amount}
 */
function calculateTip(subtotal, percent) {
    // Doing the math.
    return subtotal * percent / 100;
}

// Function to print the receipt preview.
/**
 * Name: printReceipt
 * Purpose: Prints the receipt for the customer.
 * @param {Object} order 
 * @param {Object} prices 
 */
function printReceipt(order, prices) {
    // Variable to create a string to actually print for the user to see.
    let receipt = "";

    // Print receipt header and entrée items
    receipt += "EPIC BYTE BISTRO RECEIPT – " + order.customer + "\n";
    receipt += "Date: " + order.date + "\n";
    receipt += "--------------------\n";

    // Print receipt header and entrée items to the console.
    console.log("EPIC BYTE BISTRO RECEIPT – " + order.customer);
    console.log("Date: " + order.date);
    console.log("----------------------------------------");

    // Printing out the cost of all entrees.
    if (Array.isArray(order.entrees)) {
        order.entrees.forEach(function(item) {
            const cost = prices[item.name] * item.qty;
            receipt += `Entrée: ${item.name} x${item.qty} – $${cost.toFixed(2)}\n`;
            console.log("Entrée: " + item.name + " x" + item.qty + " – $" + cost.toFixed(2));
        });
    }

    // Printing out the cost of all drinks.
    if (Array.isArray(order.drinks)) {
        order.drinks.forEach(function(item) {
            const cost = prices[item.name] * item.qty;
            receipt += `Drink: ${item.name} x${item.qty} – $${cost.toFixed(2)}\n`;
            console.log("Drink: " + item.name + " x" + item.qty + " – $" + cost.toFixed(2));
        });
    }

    // Printing out the cost of all desserts.
    if (Array.isArray(order.desserts)) {
        order.desserts.forEach(function(item) {
            const cost = prices[item.name] * item.qty;
            receipt += `Dessert: ${item.name} x${item.qty} – $${cost.toFixed(2)}\n`;
            console.log("Dessert: " + item.name + " x" + item.qty + " – $" + cost.toFixed(2));
        });
    }

    // Printing out the cost of all addons.
    if (Array.isArray(order.addOns)) {
        order.addOns.forEach(function(addOn) {
            const cost = prices[addOn];
            receipt += `Add-on: ${addOn} – $${cost.toFixed(2)}\n`;
            console.log("Add-on: " + addOn + " – $" + cost.toFixed(2));
        });
    }

    /* Sending that same info to the console. OG Code: Unnecessary now. */
    {
    
    /*
    // Print receipt header and entrée items
    console.log("EPIC BYTE BISTRO RECEIPT – " + order.customer);
    console.log("Date: " + order.date);
    console.log("----------------------------------------");
  
    // Printing out the cost of all entrees.
    if (Array.isArray(order.entrees)) {
      order.entrees.forEach(function(item) {
        const cost = prices[item.name] * item.qty;
        console.log("Entrée: " + item.name + " x" + item.qty + " – $" + cost.toFixed(2));
      });
    }
  
    // Printing out the cost of all drinks.
    if (Array.isArray(order.drinks)) {
      order.drinks.forEach(function(item) {
        const cost = prices[item.name] * item.qty;
        console.log("Drink: " + item.name + " x" + item.qty + " – $" + cost.toFixed(2));
      });
    }
  
    // Printing out the cost of all desserts.
    if (Array.isArray(order.desserts)) {
      order.desserts.forEach(function(item) {
        const cost = prices[item.name] * item.qty;
        console.log("Dessert: " + item.name + " x" + item.qty + " – $" + cost.toFixed(2));
      });
    }
  
    // Printing out the cost of all addOns.
    if (Array.isArray(order.addOns)) {
      order.addOns.forEach(function(addOn) {
        const cost = prices[addOn];
        console.log("Add-on: " + addOn + " – $" + cost.toFixed(2));
      });
    }
    */
    }
  
    // Calculating the subtotal and tip.
    const subtotal = calculateSubtotal(order, prices);
    const tip = calculateTip(subtotal, order.tipPercent);
    
    // Calculating the total with or without the delivery fee.
    let total;
    if (order.delivery) {
        total = subtotal + tip + deliveryFee;
    } else {
        total = subtotal + tip;
    }

    // Printing out the delivery fee, the subtotal, the tip amount, and the total to the preview.
    receipt += "--------------------\n";
    if (order.delivery) {
        receipt += `Delivery Fee: $${deliveryFee.toFixed(2)}\n`;
    }
    receipt += `Subtotal: $${subtotal.toFixed(2)}\n`;
    receipt += `Tip (${order.tipPercent}%): $${tip.toFixed(2)}\n`;
    receipt += `TOTAL: $${total.toFixed(2)}\n`;

    // Printing out the delivery fee, the subtotal, the tip amount, and the total to the console.
    console.log("----------------------------------------");
    // Printing the delivery fee if it applies.
    if (order.delivery) {
      console.log("Delivery Fee: " + deliveryFee.toFixed(2));
    }
    console.log("Subtotal: $" + subtotal.toFixed(2));
    console.log("Tip (" + order.tipPercent + "%): " + tip.toFixed(2));
    console.log("TOTAL: $" + total.toFixed(2) + "\n");

    // Finally actually printing all the stuff added to "receipt."
    document.getElementById("receiptOutput").textContent = receipt;
}

// Adds click event listener to the reciept preview button.
document.getElementById("previewBtn").addEventListener("click", function () {
    const order = buildOrderObject();
    printReceipt(order, priceMap); // Gets renamed to "prices" throughout.
    document.getElementById("orderJson").value = JSON.stringify(order); // Hidden input for PHP.
});

// Process an actual submission.
document.querySelector("form").addEventListener("submit", function (event) {
    const order = buildOrderObject();
    document.getElementById("orderJson").value = JSON.stringify(order);
});
