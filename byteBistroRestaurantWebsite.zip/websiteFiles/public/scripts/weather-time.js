// Adding an event listener 
document.querySelectorAll('input[name="city"]').forEach(radio => {
    radio.addEventListener("change", updateCityInfo);
});

/**
 * Name: updateCityInfo
 * Purpose: Updates the city that is being displayed in map-box.
 */
function updateCityInfo() {
    // The id of the radio button is the city name
    const selectedCity = document.querySelector('input[name="city"]:checked').id;

    // Debugging statements.
    {
        console.log(`Selected city: ${selectedCity}`);

        if (!selectedCity) {
            console.log("No city selected!");
            return;
        }
    }

    // TODO: Call the function to update the map image and address based on the selected city
    updateMap(selectedCity);

    // TODO: Call the function to update business hours for the selected city
    updateHours(selectedCity);

    // TODO: Fetch and display weather and time information for the selected city
    fetchWeatherAndTime(selectedCity);
}

/**
 * Name: updateMap
 * Purpose: Updates the displayed map and triggers other updates.
 * @param {Object} city
 * @return {N/A} N/A
 */
function updateMap(city) {
    // Restaurant information.
    const mapImages = {
        cary: "images/map-city1.jpg",
        tampa: "images/map-city2.jpg",
        springfield: "images/map-city3.jpg"
    };

    const mapLinks = {
        cary: "https://www.google.com/maps/d/edit?mid=1Oat7-2qydCiSXGKZAT3iCpJdxB5GWuY&usp=drive_link",
        tampa: "https://www.google.com/maps/d/edit?mid=1al70dh7LcBwTGwcw29vf8yBN1rcaT5Q&usp=drive_link",
        springfield: "https://www.google.com/maps/d/edit?mid=106PNPyjvm3MFiTcWxqbEdbd8alV1XGk&usp=drive_link"
    };

    const addresses = {
        cary: "EBB #1: 600 Crossroads Blvd, Cary, NC 27518",
        tampa: "EBB #2: 197 E Whiting St, Tampa, FL 33602",
        springfield: "EBB #3: 774 Main St, Springfield, OR 97477"
    };

    const cityNames = {
        cary: "Cary",
        tampa: "Tampa",
        springfield: "Springfield"
    };

    // TODO: Update the map image source, alt text, map link, and address label
    document.getElementById("map-image").src = mapImages[city];
    document.getElementById("map-image").alt = `Map of ${cityNames[city]}`;
    document.getElementById("map-link").href = mapLinks[city];
    document.getElementById("map-address").innerText = addresses[city];
}

/**
 * Name: updateHours
 * Purpose: Updates the displayed hours for the correct location.
 * @param {Object} city 
 * @return {N/A} N/A
 */
function updateHours(city) {
    console.log("Hours updated.");

    // Hours for the dine-in experience.
    const dineInHoursList = {
        cary: "- 12 AM to 11 PM M-F\n- 3 AM to 12 AM Saturday\n- 5 AM to 10 PM Sunday",
        tampa: "- 2 AM to 11 PM M-F\n- 4 AM to 11 PM Saturday\n- 7 AM to 7 PM Sunday",
        springfield: "- 6 AM to 10 PM M-F\n- 4 AM to 12 AM Saturday\n- 11 AM to 10 PM Sunday"
    };

    // Delivery hours.
    const deliveryHoursList = {
        cary: "- 1 AM to 12 AM M-F\n- 4 AM to 12 AM Saturday\n- 5 AM to 10 PM Sunday",
        tampa: "- 1 AM to 10 PM M-F\n- 4 AM to 11 AM Saturday\n- 6 AM to 10 PM Sunday",
        springfield: "- 1 AM to 9 PM M-F\n- 4 AM to 10 AM Saturday\n- 7 AM to 10 PM Sunday"
    };

    // Setting the related hours.
    document.getElementById("dine-in-hours").innerText = dineInHoursList[city];
    document.getElementById("delivery-hours").innerText = deliveryHoursList[city];
}

// The weather URLs for each city.
const weatherApiUrls = {
    cary: "https://api.open-meteo.com/v1/forecast?latitude=35.756293485675904&longitude=-78.73342511626528&current=temperature_2m,weathercode&timezone=auto",
    tampa: "https://api.open-meteo.com/v1/forecast?latitude=27.94527797604693&longitude=-82.45705793197467&current=temperature_2m,weathercode&timezone=auto",
    springfield: "https://api.open-meteo.com/v1/forecast?latitude=44.04640659436758&longitude=-123.01563856024045&current=temperature_2m,weathercode&timezone=auto"
};

/**
 * Name: fetchWeatherAndTime
 * Purpose: Updates the weather and time for the location.
 * @param {Object} city 
 * @return {N/A} N/A
 */
function fetchWeatherAndTime(city) {
    console.log("Weather & time fetched.");

    const apiUrl = weatherApiUrls[city];
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const tempCelsius = data.current.temperature_2m; // Grabbing current temp.
            const tempFahrenheit = Math.round((tempCelsius * 9/5) + 32); // Converting to F.
            const weatherCode = data.current.weathercode; // Grabbing the weather code.
            const timeZone = data.timezone; // Setting the time zone.

            // Saving the time into usable formats.
            const localTime = new Date().toLocaleTimeString('en-US', {
                hour: '2-digit', minute: '2-digit', hour12: true, timeZone: timeZone
            });
            const localTime24 = new Date().toLocaleTimeString('en-US', {
                hour: '2-digit', minute: '2-digit', hour12: false, timeZone: timeZone
            });

            // Getting the local date to determine the weekday for openOrClosed.
            const localDate = new Date(data.current.time + ":00");
            const dayOfWeek = localDate.toLocaleDateString('en-US', {
                weekday: 'long',
                timeZone: timeZone
            });

            // Variable to determine if patio is potentially open.
            let patioHours = [];
            patioHours[0] = 0; // False by default.

            // Function used to determine if a location is open.
            let openOrClosed = determineOpen(city, localTime, localTime24, dayOfWeek, patioHours);

            // Changing the time showed on the page.
            displayTime(localTime, localTime24, openOrClosed);
            
            // Adjusting the displayed temp.
            document.getElementById("temperature").innerText = `${tempFahrenheit}° F`;
            
            // Updating the weather icon for day/night conditions.
            showImage("weather-icon", weatherCode, localTime);
            
            // Updating whether the patio is open or not.
            updatePatioStatus(tempFahrenheit, weatherCode, patioHours);
        });
}

/**
 * Name: showImage
 * Purpose: Changes the weather icon for daylight.
 * @param {ID} elementId
 * @param {Number} weatherCode
 * @param {String} localTimeStr
 */
function showImage(elementId, weatherCode, localTimeStr) {
    const [time, ampm] = localTimeStr.split(' ');
    const [hourStr] = time.split(':');
    let hour = parseInt(hourStr);

    // Convert to 24 hours time.
    if (ampm === "AM" && hour === 12) {
        hour = 0;
    }
    if (ampm === "PM" && hour !== 12) {
        hour += 12;
    }

    // Determining if it is daytime.
    const isDayTime = (hour >= 6 && hour < 20);

    console.log("Weather Code:", weatherCode);

    // True if less than 55.
    const isClear = weatherCode < 55;

    // Determining the weather type and time of day variables.
    let timeOfDay;
    let weatherType;
    if (isDayTime === true) {
        timeOfDay = "day";
    } else {
        timeOfDay = "night";
    }
    if (isClear === true) {
        weatherType = "Clear";
    } else {
        weatherType = "Cloudy";
    }

    // Objects representing each image.
    const weatherImages = {
        Clear: {
            day: "images/clearDay.png",
            night: "images/clearNight.png"
        },
        Cloudy: {
            day: "images/cloudyDay.png",
            night: "images/cloudyNight.png"
        }
    };

    // Selecting correct icon.
    const iconName = weatherImages[weatherType][timeOfDay];

    // Get correct image and update it.
    const img = document.getElementById(elementId);
    img.src = `${iconName}`;
}


/**
 * Name: updatePatioStatus
 * Purpose: Updates if the patio is available or not.
 * @param {Number} tempFahrenheit
 * @param {Number} weatherCode
 * @param {Array/Bool} patioHours
 */
function updatePatioStatus(tempFahrenheit, weatherCode, patioHours) {
    const patioElement = document.getElementById("patio-status");
    
    // Hiding element if patioHours[0] !== 1, meaning nothing should display for that element.
    if (!patioHours || patioHours[0] !== 1) {
        patioElement.style.display = "none";
        return;
    }

    // Show the element if dine-in available.
    patioElement.style.display = "block";

    // Displaying correct info.
    if (tempFahrenheit < 55 || tempFahrenheit > 95 || weatherCode >= 55) {
        patioElement.textContent = "Patio is CLOSED!";
        patioElement.style.color = "red";
    } else {
        patioElement.textContent = "Patio is OPEN!";
        patioElement.style.color = "green";
    }
}

/**
 * Name: displayTime
 * Purpose: Posts the time to the page.
 * @param {Time} localTime
 * @param {Time} localTime24
 * @param {Bool} openOrClosed
 * @return {N/A} N/A
 */
function displayTime(localTime, localTime24, openOrClosed) {
    let status; // Variable for where to put open or closed.

    // Determining whether the restaurant is open.
    if (openOrClosed === 1) {
        status = "Bistro Open!";
    } else {
        status = "Bistro Closed!";
    }

    // Printing the correct open/closed status and the associated time.
    document.getElementById("open-status").innerText = `${status} ${localTime}`;
}

/**
 * Name: determineOpen
 * Purpose: Determines if the restaurant is open.
 * @param {String} city
 * @param {Time} localTime
 * @param {Time} localTime24
 * @param {Week Day} dayOfWeek
 * @param {Array/Bool} patioHours
 * @return {Bool} openOrClosed
 */
function determineOpen(city, localTime, localTime24, dayOfWeek, patioHours) {
    // Storing the current hour in 24 hour format.
    const currentHour = parseInt(localTime24.split(":")[0]);

    let openOrClosed = 0; // Bool for open or closed.

    const day = dayOfWeek.toLowerCase(); // Converting the day to lowercase for comparisons.

    // The hours for each city for the later comparison.
    const dineInOpenHours = {
        cary: {
            monday: [0, 23],
            tuesday: [0, 23],
            wednesday: [0, 23],
            thursday: [0, 23],
            friday: [0, 23],
            saturday: [3, 23],
            sunday: [5, 22]
        },
        tampa: {
            monday: [2, 23],
            tuesday: [2, 23],
            wednesday: [2, 23],
            thursday: [2, 23],
            friday: [2, 23],
            saturday: [4, 23],
            sunday: [7, 19]
        },
        springfield: {
            monday: [6, 22],
            tuesday: [6, 22],
            wednesday: [6, 22],
            thursday: [6, 22],
            friday: [6, 22],
            saturday: [4, 23],
            sunday: [11, 22]
        }
    };
    const deliveryOpenHours = {
        cary: {
            monday: [1, 23],
            tuesday: [1, 23],
            wednesday: [1, 23],
            thursday: [1, 23],
            friday: [1, 23],
            saturday: [4, 23],
            sunday: [5, 22]
        },
        tampa: {
            monday: [1, 22],
            tuesday: [1, 22],
            wednesday: [1, 22],
            thursday: [1, 22],
            friday: [1, 22],
            saturday: [4, 11],
            sunday: [6, 22]
        },
        springfield: {
            monday: [1, 21],
            tuesday: [1, 21],
            wednesday: [1, 21],
            thursday: [1, 21],
            friday: [1, 21],
            saturday: [4, 10],
            sunday: [7, 22]
        }
    };

    // Retrieving the range of hours for the current day based on the week day and location.
    const dineHours = dineInOpenHours[city][day];
    const deliveryHours = deliveryOpenHours[city][day];

    // Check if currentHour is within either range
    let canDine = false; // Default to can't.
    let canDeliver = false; // Default to can't.

    // Checking dine-in hours.
    if (dineHours) { // If it exists.
        if (currentHour >= dineHours[0] && currentHour < dineHours[1]) {
            canDine = true;
            
            // Setting the patio to be available.
            patioHours[0] = 1;
        }
    }

    // Checking delivery hours.
    if (deliveryHours) { // If it exists.
        if (currentHour >= deliveryHours[0] && currentHour < deliveryHours[1]) {
            canDeliver = true;
        }
    }

    // If either is true, set openOrClosed to 1
    if (canDine || canDeliver) {
        openOrClosed = 1;
    }

    return openOrClosed; // Returning the open status of the restaurant.
}

// Manually triggering the updateCityInfo function for the default city.
document.addEventListener("DOMContentLoaded", () => {
    updateCityInfo();
});