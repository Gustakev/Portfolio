<?php
// CS 290 Activity 11 and HW 5
// Basic menu-order confirmation page with submitted values
// including JSON hidden field.
// Modify by adding your header and footer code.
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/style-custom-gustafke.css">
  <link rel="stylesheet" href="styles/style-menu-gustafke.css">
  <meta charset="UTF-8" />
  <title>Order Confirmation</title>
</head>
<body>

<header>
  <h1>Epic Byte Bistro</h1>
  <nav>
    <ul>
      <li><a href="index.html">Home</a></li>
      <li><a href="menu.html">Menu</a></li>
      <li><a href="reviews.html">Reviews</a></li>
      <li><a href="order.html">Order</a></li>
      <li><a href="menu-order.html">Interactive Order</a></li>
      <li><a href="manager-dashboard">Manager Dashboard</a></li>
    </ul>
  </nav>
</header>

<main>
<?php
// menu-order.php – Confirmation Page

// Get individual form fields
$name = $_POST['name'] ?? '(not provided)';
$tip = $_POST['tip'] ?? '(not selected)';
$delivery = $_POST['dining'];

// Get JSON object
$orderJson = $_POST['orderJson'] ?? '';
$order = json_decode($orderJson, true);

// Display confirmation
echo "<h2>Thank you for your order!</h2>";

echo "<p><strong>Name:</strong> " . htmlspecialchars($name) . "</p>";
echo "<p><strong>Tip Percentage:</strong> " . htmlspecialchars($tip) . "%</p>";
echo "<p><strong>Dining Method:</strong> " . $delivery . "</p>";

echo "<h3>Order JSON Received:</h3>";
print_r($orderJson);
?>

<!-- Holdovers from old form. -->
<p><strong>Phone:</strong> <?php echo htmlspecialchars($_POST["phone"]); ?></p>
<p><strong>Pick-up/Delivery Time:</strong> <?php echo htmlspecialchars($_POST["time"]); ?></p>
<p><strong>Special Instructions:</strong> <?php echo nl2br(htmlspecialchars($_POST["instructions"])); ?></p>

</main>

<!-- FOOTER START -->
<footer>
  <p>&copy; 2025 Epic Byte Bistro</p>
  <P>Created by: Kevin Gustafson</P>
</footer>
<!-- FOOTER END -->

</body>
</html>

