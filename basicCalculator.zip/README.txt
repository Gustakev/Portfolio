This program runs on Windows 10 and above.

This program supports basic addition, substraction, multiplication, division, and exponentiation of numbers containing decimal points or integers. It also shows a list of previously computed values after the user chooses to close the program. It also supports negative numbers. Whitespace between terms is used as a delimiter.

Open command prompt. Then, enter this folder. Then, run this program by typing this: basicCalculator.exe