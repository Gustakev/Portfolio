This program runs on Windows 10 and above.

This program runs a basketball mini-game simulation for 2 players.

Symbols:
_ = 0 pts. (Missed Shot)
X = 1 pt. (Regular Shot)
M = 2 pts. (Money Ball Shot)
S = 3 Pts. (Starry Range Shot)

Open command prompt. Then, enter this folder. Then, run this program by typing this: moneyBallRackSim.exe