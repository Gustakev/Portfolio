# CS361-Search-Service
This repository is for the Search Service that Team 44 will be implementing for use in their respective main programs for CS 361 at Oregon State University.

## Dependencies
This service requires the installation of Python 3.9+ and the following packages to run:
- pyzmq
- requests
- flask (only required for "searchGateway.py")
- flask-cors (only required for "searchGateway.py")

Install these packages quickly by opening Git Bash, or another terminal, and entering "pip install -r requirements.txt".

## Instructions
1. Create a "data.json" file in the same directory as "searchService.py". It should be formatted like this example data, in order to use local file search:

	```JSON
	[
		{"title": "Apple fruit basics", "url": "https://fruit.com/apple", "content": "Apples are fruits..."},
		{"title": "Banana nutrition facts", "url": "https://fruit.com/banana", "content": "Bananas are yellow..."},
		{"title": "Cherry varieties", "url": "https://fruit.com/cherry", "content": "Cherries are small..."}
	]
	```

2. Start the program by entering "python searchService.py" into your terminal.

3. The client must send a message over ZeroMQ using the number of the port constant in "searchService.py" called "PORT" (defaultly set to 8000) fulfilling the following requirements:
   - The message must be JSON formatted data of the form:

	```JSON
	{
		"query": "apple",
		"mode": "preview",
		"source": "local"
	}
	```

	... such that, for example, the 'query' could be any text string, e.g., "cars in the room", the 'mode' could be "preview" or "search", and the 'source' could be "local" or "wikipedia".

4. The client must be prepared to receive a response over ZeroMQ using same port (defaultly set to 8000) fulfilling the following requirements:
   - The response will be JSON formatted data of the form:

	**For Previews:**
	```JSON
	{
		"ok": True,
		"mode": "preview",
		"query_received": "apple",
		"results": [
			{
				"title": "Apple fruit basics",
				"url": "https://fruit.com/apple",
				"content": "Apples are fruits..."
			},
			{
				"title": "Banana nutrition facts",
				"url": "https://fruit.com/banana",
				"content": "Bananas are yellow..."
			},
			{
				"title": "Cherry varieties",
				"url": "https://fruit.com/cherry",
				"content": "Cherries are small..."
			}
		],
		"timestamp_ms": 1731730000000
	}
	```

	### Note: The response for a 'preview' will return 3 objects (by default) stored within 'results' when a 'preview' is requested, as shown above.

	**For Searches:**
	```JSON
	{
		"ok": True,
		"mode": "search",
		"query_received": "machine learning",
		"results": [
			{
				"title": "Machine learning",
				"url": "https://en.wikipedia.org/wiki/Machine_learning",
				"content": "Machine learning is a field of AI...",
				"relevance": 1.0
			},
			{
				"title": "Artificial intelligence",
				"url": "https://en.wikipedia.org/wiki/Artificial_intelligence",
				"content": "Artificial intelligence overlaps with ML...",
				"relevance": 0.95
        	}
		],
		"timestamp_ms": 1731730005000
	}
	```
	### Note: The actual program will return 10 objects (by default) stored within 'results' when a 'search' is done, not just 2.

	**For Errors:**
	```JSON
	{
		"ok": False,
		"error": str(valError)
	}
	```

## Possible Variations in Responses:
- **Preview Responses:**
  - The 'query_received' will be a lowercase version of the query sent.
  - The 'timestamp_ms' will differ.
  - The 'title', 'url', and 'content' of each of the objects in 'results' will differ.

- **Search Responses:**
  - The differences are the same as for the preview responses, except that each of the objects in 'results' now have a relevance score value from 0 to 1.

- **Error Responses:**  
  - These only differ by 'valError' value.

## How to Programatically Send and Receive Data (Example):
```python
	import zmq
	import json

	# Create request pipeline
	context = zmq.Context()
	socket = context.socket(zmq.REQ)
	socket.connect("tcp://localhost:8000")

	# Send the request
	socket.send_json({
		"query": "dog",
		"mode": "search",
		"source": "wikipedia"
	})

	# Receive a response and print it
	response = socket.recv_json()
	print(json.dumps(response, indent=2))

```

## UML Diagram
![UML Diagram](UML-Diagram.jpg)
