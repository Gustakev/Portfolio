# Authors: Kevin Gustafson, Conner Dillavou
# Date: 11/15/2025
# Purpose: This microservice exists to be the server that can communicate between the
#  HTML page that is our test program's UI and the Search Service itself.

from flask import Flask, request, jsonify
from flask_cors import CORS
import zmq
import json

app = Flask(__name__)
CORS(app)  

context = zmq.Context()
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:8000") 

@app.route("/search", methods=["POST"])
def search():
    data = request.json

    socket.send_json(data)
    response = socket.recv_json()

    return jsonify(response)

if __name__ == "__main__":
    app.run(port=5000, debug=True)