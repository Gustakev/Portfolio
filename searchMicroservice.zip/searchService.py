# Authors: Kevin Gustafson, Conner Dillavou
# Date: 11/15/2025
# Purpose: This microservice queries either a local file or Wikipedia and returns either
#  a preview or a full response based on the query.

import zmq
import json
import requests
import re
import time
import html

# Constants:
PREVIEW_LIMIT = 3
SEARCH_LIMIT = 10
RELEVANCE_STEP = 0.05
PORT = 8000
LOCAL_DATA_FILE = "data.json"
WIKIPEDIA_API_URL = "https://en.wikipedia.org/w/api.php"
USER_AGENT = "CS361-Search-Service (University Project)"

#-- Utility Functions --#

# Name: clean_snippet
# Description: Cleans up the formatting of a Wikipedia snippet before it is used in the
#  response.
def clean_snippet(snippet):
    # Removing HTML stuff.
    text = re.sub(r"<.*?>", "", snippet)
    # Converting HTML string snippets with special character references into their
    #  unicode versions.
    text = html.unescape(text)
    # Removing the returned Wikipedia template junk like {{{1}}} or {{cite ...}}.
    text = re.sub(r"\{\{[^{}]*\}\}", "", text)
    return text.strip()

# Name: normalize
# Description: Normalizing a string by stripping whitespace, setting it to lowercase, and
#  handling value == None by returning "".
def normalize(value):
    if value is None:
        return ""
    return str(value).strip().lower()

# Name: json_item_to_text
# Description: Converts a JSON item into a lowercase string for better search
#  compatibility.
def json_item_to_text(json_item):
    try:
        return json.dumps(json_item, ensure_ascii=False).lower()
    except:
        return str(json_item).lower()

#-- Data Providing Functions --#

# Name: choose_provider
# Description: Picks the data provider based on the specified source argument, and then
#  returns a response from the correct data source, or raises an error about the data
#  source if it doesn't exist.
def choose_provider(source, query):
    # If the source is left blank or manually said to be 'local', it will default to
    #  a local query.
    if source == "" or source == "local":
        return load_local_data(query)
    elif source == "wikipedia":
        return fetch_wikipedia_data(query)
    else:
        # Error thrown if source doesn't exist. To be handled by caller.
        raise ValueError(f"Data source named '{source}' does not exist.")

# Name: load_local_data
# Description: Opens the local data file called 'data.json' and store its JSON in data
#  var.
def load_local_data(query):
    # Open file in read mode and store contents as data variable in UTF-8.
    with open(LOCAL_DATA_FILE, "r", encoding="utf-8") as file:
        data = json.load(file)
    # Query is normalized, and then, every item in the data that matches it is returned.
    q = normalize(query)
    return [json_item for json_item in data if q in json_item_to_text(json_item)]

# Name: fetch_wikipedia_data
# Description: Responds from Wikipedia, rather than a local file, and returns it in the
#  same format the local file data is stored in.
def fetch_wikipedia_data(query):
    # API endpoint:
    url = WIKIPEDIA_API_URL
    # Required parameters for a Wikipedia query requesting JSON:
    params = {
        "action": "query",
        "list": "search",
        "srsearch": query,
        "format": "json"
    }
    # User agent so Wikipedia knows who is accessing their API (required):
    headers = {
        "User-Agent": USER_AGENT
    }
    # Querying the Wikipedia API for a response and storing it.
    response = requests.get(url, params=params, headers=headers)
    # Handling all Wikipedia response error codes:
    if response.status_code != 200:
        raise ValueError(f"Wikipedia API Error: {response.status_code}.")
    # Converting the JSON response into a Python dictionary:
    raw = response.json()
    # Handling error for wrong data format being returned:
    if "query" not in raw or "search" not in raw["query"]:
        raise ValueError("Wikipedia API returned an unexpected format.")
    # Creating the results list using each returned key value pair:
    results = []
    for item in raw["query"]["search"]:
        # Ensuring proper formatting for each title, each URL, and cleaning the content
        #  snippets.
        results.append({
            "title": item["title"],
            "url": f"https://en.wikipedia.org/wiki/{item['title'].replace(' ', '_')}",
            "content": clean_snippet(item["snippet"])
        })
    return results

#-- Search Functions --#

# Name: run_lightweight_search
# Description: Returns 3 results with only their basic fields, no relevance field.
def run_lightweight_search(results):
    return results[:PREVIEW_LIMIT]

# Name: run_full_search
# Description: Returns 10 detailed results, including relevance scores.
def run_full_search(results):
    final_results = []
    # Appending 10 results to final results with created relevance scores attached.
    for i, item in enumerate(results[:SEARCH_LIMIT]):
        # Round scores; avoid oddities.
        item["relevance"] = round(1.0 - (i * RELEVANCE_STEP), 2)
        final_results.append(item)
    return final_results

# Create and return a ZeroMQ socket bound to the given port.
def create_zmq_socket(port):
    
    context = zmq.Context()
    socket = context.socket(zmq.REP)
    socket.bind(f"tcp://*:{port}")
    print(f"Search microservice running on port {port}...")
    return socket

# Fetch data, run search, and build JSON response.
def build_response(query, mode, source):
    if not query.strip():
        return {"ok": False, "error": "Query can't be empty."}

    try:
        data = choose_provider(source, query)
        results = run_lightweight_search(data) if mode == "preview" else run_full_search(data)
        return {
            "ok": True,
            "mode": mode,
            "query_received": str(query),
            "results": results,
            "timestamp_ms": int(time.time() * 1000)
        }
    except ValueError as valError:
        return {"ok": False, "error": str(valError)}

# Name: main
# Description: Sets up the connection to another program that utilizes this microservice.
#  Checks for queries from another program and responds as fast as possible, then loops.
def main():
    # Main loop for the search microservice:
    socket = create_zmq_socket(PORT)

    while True:
        message = socket.recv_json()
        query = message.get("query", "")
        mode = message.get("mode", "search")
        source = message.get("source", "")

        response = build_response(query, mode, source)
        socket.send_json(response)
        
# Prevents program from starting automatically if imported into another.
if __name__ == "__main__":
    main()
