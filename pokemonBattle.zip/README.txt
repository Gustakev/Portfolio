This program runs on Windows 10 and above.

This program offers a Pokemon battle simulation in which 2 trainers can battle one another. There are 4 Pokemon to choose from.

Open command prompt. Then, enter this folder. Then, run this program by typing this: pokemonBattle.exe